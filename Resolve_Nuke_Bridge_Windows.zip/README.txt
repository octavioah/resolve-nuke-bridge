RESOLVE <-> NUKE BRIDGE  (Windows)
====================================
Personal tool by Octavio Alonso.

Sends a clip from a DaVinci Resolve timeline to Nuke, lets you
composite, and sends the result back automatically -- no manual
importing, no track shuffling, no lost work between iterations.


REQUIREMENTS
------------
Before installing, make sure you have all of the following:

1. DaVinci Resolve STUDIO
   The free version of Resolve does not expose the scripting API
   this tool needs. Resolve Studio is required.

2. Nuke or NukeX (any recent version)

3. Python 3 from python.org  <-- REQUIRED, read carefully
   Resolve needs Python to run scripts. Nuke ships with its own
   Python but it is not compatible with Resolve's scripting DLL on
   Windows, so a separate Python installation is required.

   Download Python from:
   https://www.python.org/downloads/

   During installation, on the first screen, tick the checkbox:
   "Add Python to PATH"
   This checkbox is UNTICKED by default. Without it, Resolve will
   not find Python and the scripts will not appear in the menu.

   Any Python 3.x version works (3.10, 3.12, 3.14, etc.).
   After installing Python, restart Resolve.

4. External scripting enabled in Resolve
   In Resolve, go to:
   Preferences > General > External scripting using
   Set it to "Local". Without this, Resolve will not accept
   connections from external scripts.


FILES IN THIS PACKAGE
---------------------
resolve_nuke_bridge_common.py  -- shared module (goes in BOTH places)
SendToNuke.py                  -- Resolve side
ReopenInNuke.py                -- Resolve side
send_back_to_resolve.py        -- Nuke side
resolve_sender.py              -- Nuke side (helper, Windows only)


INSTALLATION
------------

STEP 1 -- RESOLVE SIDE
  Copy these three files to your Resolve Scripts/Edit folder:

    C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Edit\

  Files to copy:
    - resolve_nuke_bridge_common.py
    - SendToNuke.py
    - ReopenInNuke.py

  Notes:
    - ProgramData is a hidden folder. In File Explorer, go to
      View > Show > Hidden items to make it visible.
    - The "Edit" subfolder may not exist -- create it if it doesn't.
    - You may need administrator rights to write to this folder.
      If so, copy the files to your Desktop first, then move them
      to the Scripts/Edit folder using "Run as administrator" or
      by asking your system administrator.

  Restart Resolve. The scripts appear under Workspace > Scripts.

  To verify the scripts are detected: in Resolve open
  Workspace > Console, switch the dropdown from "Lua" to "Py3",
  and type: print("ok")
  If it shows "Py3 not found", Python is not installed or not
  in PATH (see Requirements above).


STEP 2 -- NUKE SIDE
  Copy these FOUR files to your ~/.nuke/ folder:
    - resolve_nuke_bridge_common.py
    - send_back_to_resolve.py
    - resolve_sender.py              <- Windows only, do not skip this
    - (optionally) ReopenInNuke.py   <- if you want it in Nuke too

  To find your ~/.nuke/ folder:
    Open File Explorer and type this in the address bar:
    %USERPROFILE%\.nuke
    (e.g. C:\Users\YourName\.nuke)

  Then open the file .nuke\menu.py in Notepad and add this line
  at the end (create the file if it does not exist):
    import send_back_to_resolve

  Restart Nuke. A new menu item appears:
    Render > Send back to Resolve
  Keyboard shortcut: Ctrl+Alt+R

  WHY resolve_sender.py IS NEEDED ON WINDOWS:
    Nuke on Windows ships with Python 3.11, but Resolve's scripting
    DLL (fusionscript.dll) is not compatible with Python 3.11. If
    Nuke tried to connect to Resolve directly it would crash with a
    SystemError. resolve_sender.py is a small helper script that runs
    as a separate process using the system Python (the one you
    installed from python.org), which IS compatible with Resolve.
    This happens automatically -- you do not need to do anything
    extra, just make sure the file is in the same folder as
    send_back_to_resolve.py.


HOW TO USE
----------

SENDING A CLIP TO NUKE
  1. Open Resolve on the Edit or Cut page.
  2. Move the PLAYHEAD over the clip you want to send to Nuke
     (click on the clip in the timeline to move the playhead there).
     Note: the Resolve scripting API does not expose which clip is
     visually "selected" -- it only knows which clip is under the
     playhead. This is the same behavior as the native Send to
     Fusion feature.
  3. In Resolve, go to Workspace > Scripts > SendToNuke.

     FIRST TIME with this clip:
       A folder picker appears. Choose where to save the Nuke
       project (e.g. a "nuke" folder next to your footage).
       Resolve then:
         - Renders the full source material to EXR, preserving the
           original frame numbering (e.g. 1001-1100, not 0-99)
         - Imports that render into the Media Pool as a reference
           copy (your pre-Nuke original)
         - Opens Nuke automatically with a Read and Write node
           already set up

     SUBSEQUENT TIMES with the same clip:
       No folder picker. The existing .nk is reused with all your
       compositing work intact. Only the source material is
       re-rendered fresh from Resolve.

COMPOSITING IN NUKE
  Work normally. The Read node points at the EXR render from
  Resolve. The Write node (ResolveBridge_Write1) is pre-configured;
  do not rename or delete it.

  IMPORTANT -- COLORSPACE: the Read and Write nodes are set to
  "sRGB", which matches a standard Rec.709 Resolve project. If your
  project uses a different color space (Log, ACES, Linear...), you
  must change the colorspace knob on BOTH the Read and Write nodes
  before compositing, or the result will look wrong. A yellow sticky
  note in the .nk reminds you of this when you first open it.

SENDING THE RESULT BACK TO RESOLVE
  When done compositing, go to Render > Send back to Resolve
  (or press Ctrl+Alt+R).
  Nuke renders and sends the result back automatically. Resolve
  updates the original clip in place -- no new tracks are created,
  nothing shifts around in your edit.

  Note: ReplaceClip() updates the clip's MediaPoolItem directly,
  so if the same source material appears in more than one place in
  your project, all instances update simultaneously. Undo (Ctrl+Z)
  in Resolve reverts it if needed.

REOPENING AN IN-PROGRESS SHOT
  If you closed Nuke before sending the result back, or want to
  continue working on a shot later:
    1. In Resolve, place the playhead over the clip
    2. Run Workspace > Scripts > ReopenInNuke
  This reopens Nuke with the existing .nk without re-rendering
  anything.


FOLDER STRUCTURE
----------------
Each clip gets its own job folder inside the directory you chose:

  YourChosenFolder\
    ClipName_YYYYMMDD_HHMMSS\
      from_resolve\        <- EXR render from Resolve
                              (Nuke reads from here; also serves as
                              your pre-Nuke reference in the Media Pool)
      from_nuke\           <- EXR render from Nuke (sent back to Resolve)
      comp.nk              <- your Nuke composition
      bridge_metadata.json <- internal bookkeeping, do not edit

A small index file at %USERPROFILE%\NukeResolveBridge\job_index.json
maps each Resolve clip to its job folder. If you move a job folder,
the script detects that the .nk is gone and creates a new job the
next time you send that clip. Deleting the index makes the script
forget all jobs (the job folders themselves are not deleted).


TROUBLESHOOTING
---------------

Scripts don't appear in Workspace > Scripts
  Most likely cause: Python is not installed or not in PATH.
  1. Download Python from https://www.python.org/downloads/
  2. Run the installer and tick "Add Python to PATH" on the first
     screen (it is unticked by default).
  3. Restart Resolve.
  To verify: in Resolve open Workspace > Console, switch from "Lua"
  to "Py3", and type: print("ok")
  If it says "Py3 not found", Python is still not configured.

"Module not found" error when running SendToNuke
  resolve_nuke_bridge_common.py must be in the same folder as
  SendToNuke.py. Check that all three Resolve-side files are in:
  C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Edit\

Nuke does not open after the render
  The script says "Nuke launched" in the console but Nuke does not
  appear. To check which executable the script found:
  In Resolve's console (Py3) run:
    import sys
    sys.path.append(r"C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Edit")
    import resolve_nuke_bridge_common as bridge
    print(bridge.find_nuke_executable())
  If the path shown is wrong, set the environment variable
  NUKE_BRIDGE_EXECUTABLE to the full path of your Nuke .exe
  (e.g. C:\Program Files\Nuke17.0v1\Nuke17.0.exe).

"Could not connect to Resolve" or "initialization of fusionscript
failed" when sending back from Nuke
  This is the Windows Python incompatibility issue. Make sure:
  - resolve_sender.py is in the same folder as send_back_to_resolve.py
    (~/.nuke/ or %USERPROFILE%\.nuke\)
  - Python is installed from python.org and in PATH (the script uses
    the system Python, not Nuke's bundled one, to talk to Resolve)
  - Resolve is open with External scripting set to Local

Send back to Resolve menu item does not appear in Nuke
  Make sure these files are all in %USERPROFILE%\.nuke\:
    - send_back_to_resolve.py
    - resolve_sender.py
    - resolve_nuke_bridge_common.py
  And that %USERPROFILE%\.nuke\menu.py contains:
    import send_back_to_resolve
  Restart Nuke after any changes to menu.py.
