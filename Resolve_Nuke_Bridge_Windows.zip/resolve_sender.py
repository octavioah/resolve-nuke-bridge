"""
resolve_sender.py
==================
Intermediary script launched by send_back_to_resolve.py as a
subprocess using the SYSTEM Python (not Nuke's bundled Python).

WHY THIS EXISTS: on Windows, Nuke ships with its own Python (3.11)
which is incompatible with Resolve's fusionscript.dll (compiled for
Python 3.10 or earlier). Loading fusionscript.dll inside Nuke's
Python process raises a SystemError. The solution is to run this
script as a subprocess with the system Python, which IS compatible
with Resolve's scripting API.

This script is called automatically by send_back_to_resolve.py.
Do not run it manually.

Usage: python resolve_sender.py <job_dir> <first_rendered_file>
"""

import sys
import os


def main():
    if len(sys.argv) < 3:
        print("Usage: resolve_sender.py <job_dir> <first_rendered_file>")
        sys.exit(1)

    job_dir = sys.argv[1]
    first_rendered = sys.argv[2]

    # Add the Resolve scripting modules to sys.path and the Resolve
    # install folder to the DLL search path.
    import platform
    if platform.system() == "Windows":
        programdata = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
        program_files = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        modules_dir = os.path.join(
            programdata,
            "Blackmagic Design", "DaVinci Resolve",
            "Support", "Developer", "Scripting", "Modules"
        )
        resolve_dir = os.path.join(
            program_files, "Blackmagic Design", "DaVinci Resolve"
        )
        if modules_dir not in sys.path:
            sys.path.append(modules_dir)
        os.environ["PATH"] = resolve_dir + os.pathsep + os.environ.get("PATH", "")
        if hasattr(os, "add_dll_directory"):
            try:
                os.add_dll_directory(resolve_dir)
            except Exception:
                pass
    else:
        api = "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting"
        modules_dir = os.path.join(api, "Modules")
        if modules_dir not in sys.path:
            sys.path.append(modules_dir)

    try:
        import DaVinciResolveScript as dvr_script
    except (ImportError, SystemError) as e:
        print(f"ERROR: Could not import DaVinciResolveScript: {e}")
        print("Make sure DaVinci Resolve Studio is installed and running.")
        sys.exit(1)

    try:
        resolve = dvr_script.scriptapp("Resolve")
    except Exception as e:
        print(f"ERROR: Could not connect to Resolve: {e}")
        sys.exit(1)

    if resolve is None:
        print("ERROR: Could not connect to Resolve. Is it open with the right project?")
        sys.exit(1)

    # Read the metadata to find the original MediaPoolItem
    import json
    metadata_path = os.path.join(job_dir, "bridge_metadata.json")
    try:
        with open(metadata_path, encoding="utf-8") as f:
            metadata = json.load(f)
    except Exception as e:
        print(f"ERROR: Could not read metadata from {metadata_path}: {e}")
        sys.exit(1)

    unique_id = metadata.get("media_pool_item_id")
    clip_name = metadata.get("clip_name", "?")

    project_manager = resolve.GetProjectManager()
    project = project_manager.GetCurrentProject() if project_manager else None
    if project is None:
        print("ERROR: No project is currently open in Resolve.")
        sys.exit(1)

    # Find the MediaPoolItem by its unique ID
    def find_item(folder, uid):
        for item in (folder.GetClipList() or []):
            try:
                if item.GetUniqueId() == uid:
                    return item
            except Exception:
                pass
        for subfolder in (folder.GetSubFolderList() or []):
            found = find_item(subfolder, uid)
            if found:
                return found
        return None

    media_pool = project.GetMediaPool()
    root = media_pool.GetRootFolder()
    media_pool_item = find_item(root, unique_id)

    if media_pool_item is None:
        print(f"ERROR: Could not find clip '{clip_name}' in the Media Pool.")
        sys.exit(1)

    try:
        success = media_pool_item.ReplaceClip(first_rendered)
    except Exception as e:
        print(f"ERROR: ReplaceClip failed: {e}")
        sys.exit(1)

    if success:
        try:
            print(f"SUCCESS: '{clip_name}' updated in Resolve.")
        except UnicodeEncodeError:
            print("SUCCESS: clip updated in Resolve.")
    else:
        print(f"ERROR: ReplaceClip returned False for '{clip_name}'.")
        sys.exit(1)


if __name__ == "__main__":
    main()
