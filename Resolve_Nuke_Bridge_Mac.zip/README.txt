RESOLVE <-> NUKE BRIDGE  (macOS)
==================================
Personal tool by Octavio Alonso.

Sends a clip from a DaVinci Resolve timeline to Nuke, lets you
composite, and sends the result back automatically -- no manual
importing, no track shuffling, no lost work between iterations.


REQUIREMENTS
------------
Before installing, make sure you have all of the following:

1. DaVinci Resolve STUDIO
   The free version of Resolve does not expose the scripting API
   this tool needs. Resolve Studio is required.

2. Nuke or NukeX (any recent version)

3. Python 3 from python.org
   macOS ships with its own Python but it does not work with
   Resolve's scripting API. You need to install Python from:
   https://www.python.org/downloads/
   Download the macOS installer (.pkg), run it, and follow the
   steps. No special configuration needed during installation.

4. External scripting enabled in Resolve
   In Resolve, go to:
   Preferences > General > External scripting using
   Set it to "Local". Without this, Resolve will not accept
   connections from external scripts.


FILES IN THIS PACKAGE
---------------------
resolve_nuke_bridge_common.py  -- shared module (goes in BOTH places)
SendToNuke.py                  -- Resolve side
ReopenInNuke.py                -- Resolve side
send_back_to_resolve.py        -- Nuke side


INSTALLATION
------------

STEP 1 -- RESOLVE SIDE
  Copy these three files to your Resolve Scripts/Edit folder:

    /Library/Application Support/Blackmagic Design/
      DaVinci Resolve/Fusion/Scripts/Edit/

  Files to copy:
    - resolve_nuke_bridge_common.py
    - SendToNuke.py
    - ReopenInNuke.py

  To get to this folder in Finder:
    1. Open Finder
    2. In the menu bar click Go > Go to Folder...
    3. Paste this path:
       /Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Edit
    4. Press Enter

  If the "Edit" folder does not exist, create it.

  Restart Resolve. The scripts appear under Workspace > Scripts.


STEP 2 -- NUKE SIDE
  Copy these two files to your ~/.nuke/ folder:
    - resolve_nuke_bridge_common.py
    - send_back_to_resolve.py

  To find ~/.nuke/ in Finder:
    1. Open Finder
    2. In the menu bar click Go > Go to Folder...
    3. Type: ~/.nuke
    4. Press Enter

  Then open the file ~/.nuke/menu.py in a text editor and add
  this line at the end (create the file if it does not exist):
    import send_back_to_resolve

  Restart Nuke. A new menu item appears:
    Render > Send back to Resolve
  Keyboard shortcut: Ctrl+Alt+R


HOW TO USE
----------

SENDING A CLIP TO NUKE
  1. Open Resolve on the Edit or Cut page.
  2. Move the PLAYHEAD over the clip you want to send to Nuke
     (click on the clip in the timeline to move the playhead there).
     Note: the Resolve scripting API does not expose which clip is
     visually "selected" -- it only knows which clip is under the
     playhead. This is the same behavior as the native Send to
     Fusion feature.
  3. In Resolve, go to Workspace > Scripts > SendToNuke.

     FIRST TIME with this clip:
       A folder picker appears. Choose where to save the Nuke
       project (e.g. a "nuke" folder next to your footage).
       Resolve then:
         - Renders the full source material to EXR, preserving the
           original frame numbering (e.g. 1001-1100, not 0-99)
         - Imports that render into the Media Pool as a reference
           copy (your pre-Nuke original)
         - Opens Nuke automatically with a Read and Write node
           already set up

     SUBSEQUENT TIMES with the same clip:
       No folder picker. The existing .nk is reused with all your
       compositing work intact. Only the source material is
       re-rendered fresh from Resolve.

COMPOSITING IN NUKE
  Work normally. The Read node points at the EXR render from
  Resolve. The Write node (ResolveBridge_Write1) is pre-configured;
  do not rename or delete it.

  IMPORTANT -- COLORSPACE: the Read and Write nodes are set to
  "sRGB", which matches a standard Rec.709 Resolve project. If your
  project uses a different color space (Log, ACES, Linear...), you
  must change the colorspace knob on BOTH the Read and Write nodes
  before compositing, or the result will look wrong. A yellow sticky
  note in the .nk reminds you of this when you first open it.

SENDING THE RESULT BACK TO RESOLVE
  When done compositing, go to Render > Send back to Resolve
  (or press Ctrl+Alt+R).
  Nuke renders and sends the result back automatically. Resolve
  updates the original clip in place -- no new tracks are created,
  nothing shifts around in your edit.

  Note: ReplaceClip() updates the clip's MediaPoolItem directly,
  so if the same source material appears in more than one place in
  your project, all instances update simultaneously. Undo (Ctrl+Z)
  in Resolve reverts it if needed.

REOPENING AN IN-PROGRESS SHOT
  If you closed Nuke before sending the result back, or want to
  continue working on a shot later:
    1. In Resolve, place the playhead over the clip
    2. Run Workspace > Scripts > ReopenInNuke
  This reopens Nuke with the existing .nk without re-rendering
  anything.


FOLDER STRUCTURE
----------------
Each clip gets its own job folder inside the directory you chose:

  YourChosenFolder/
    ClipName_YYYYMMDD_HHMMSS/
      from_resolve/        <- EXR render from Resolve
                              (Nuke reads from here; also serves as
                              your pre-Nuke reference in the Media Pool)
      from_nuke/           <- EXR render from Nuke (sent back to Resolve)
      comp.nk              <- your Nuke composition
      bridge_metadata.json <- internal bookkeeping, do not edit

A small index file at ~/NukeResolveBridge/job_index.json maps each
Resolve clip to its job folder. If you move a job folder, the script
detects that the .nk is gone and creates a new job the next time you
send that clip. Deleting the index makes the script forget all jobs
(the job folders themselves are not deleted).


TROUBLESHOOTING
---------------

Scripts don't appear in Workspace > Scripts
  Make sure Python from python.org is installed (not the macOS
  system Python). Restart Resolve after installing Python.
  To verify: in Resolve open Workspace > Console, switch the
  dropdown from "Lua" to "Py3", and type: print("ok")
  If it says "Py3 not found", Python is not installed correctly.

"Could not connect to Resolve" when sending back from Nuke
  Make sure:
  - Resolve is open and a project is loaded
  - Preferences > General > External scripting using = Local
  - You are using a Python installed from python.org, not the
    macOS system Python

Nuke does not open after the render
  The script prints "Nuke launched" in the Resolve console but
  Nuke does not open. Check what executable the script found:
  in Resolve's console (Py3) run:
    import sys
    sys.path.append("/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Edit")
    import resolve_nuke_bridge_common as bridge
    print(bridge.find_nuke_executable())
  If the path is wrong, set the environment variable
  NUKE_BRIDGE_EXECUTABLE to the full path of your Nuke app.

Send back to Resolve menu item does not appear in Nuke
  Make sure send_back_to_resolve.py and resolve_nuke_bridge_common.py
  are both in ~/.nuke/ and that ~/.nuke/menu.py contains:
    import send_back_to_resolve
  Restart Nuke after any changes to menu.py.
